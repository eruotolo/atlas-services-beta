--
-- PostgreSQL database dump
--

\restrict I6oaAwYpg956hZ2G3ltMfFH33VmGsP7FlreKSRTJJbOLswrGA6zuPvIEKAtj7VR

-- Dumped from database version 17.7 (e429a59)
-- Dumped by pg_dump version 17.7 (Homebrew)

-- Started on 2026-01-22 02:53:33 -03

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 860 (class 1247 OID 24582)
-- Name: CategoriaSponsor; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CategoriaSponsor" AS ENUM (
    'SENIOR',
    'PREMIUM',
    'STANDARD'
);


--
-- TOC entry 863 (class 1247 OID 24590)
-- Name: EstadoComentario; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EstadoComentario" AS ENUM (
    'PENDIENTE',
    'ACTIVO',
    'ELIMINADO'
);


--
-- TOC entry 857 (class 1247 OID 24577)
-- Name: NivelServicio; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NivelServicio" AS ENUM (
    'BASICO',
    'PREMIUM'
);


--
-- TOC entry 893 (class 1247 OID 32769)
-- Name: TipoInteraccion; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipoInteraccion" AS ENUM (
    'VER_TELEFONO',
    'VER_EMAIL',
    'LLAMAR',
    'WHATSAPP'
);


--
-- TOC entry 902 (class 1247 OID 57749)
-- Name: TipoRedSocial; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipoRedSocial" AS ENUM (
    'WEBSITE',
    'FACEBOOK',
    'INSTAGRAM',
    'LINKEDIN',
    'TIKTOK',
    'TWITTER',
    'YOUTUBE',
    'OTRO'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 227 (class 1259 OID 41121)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 24645)
-- Name: calificaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calificaciones (
    id text NOT NULL,
    "servicioId" text NOT NULL,
    "usuarioId" text NOT NULL,
    estrellas integer NOT NULL,
    comentario text,
    estado public."EstadoComentario" DEFAULT 'ACTIVO'::public."EstadoComentario" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 220 (class 1259 OID 24622)
-- Name: categoriaservicios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoriaservicios (
    id text NOT NULL,
    nombre text NOT NULL,
    slug text NOT NULL,
    icono text,
    orden integer DEFAULT 0 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 32777)
-- Name: interacciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interacciones (
    id text NOT NULL,
    tipo public."TipoInteraccion" NOT NULL,
    "servicioId" text NOT NULL,
    "usuarioId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 24675)
-- Name: precios_premium; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.precios_premium (
    id text NOT NULL,
    "duracionMeses" integer NOT NULL,
    precio numeric(10,2) NOT NULL,
    descripcion text,
    activo boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 57765)
-- Name: redes_sociales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.redes_sociales (
    id text NOT NULL,
    "servicioId" text NOT NULL,
    tipo public."TipoRedSocial" NOT NULL,
    url text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 24605)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text NOT NULL,
    nombre text NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 24632)
-- Name: servicios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.servicios (
    id text NOT NULL,
    "usuarioId" text NOT NULL,
    titulo text NOT NULL,
    slug text NOT NULL,
    "categoriaId" text NOT NULL,
    descripcion text NOT NULL,
    precio numeric(10,2) NOT NULL,
    comuna text NOT NULL,
    "imagenPrincipal" text,
    imagenes text[],
    "calificacionPromedio" numeric(2,1),
    "totalCalificaciones" integer DEFAULT 0 NOT NULL,
    destacado boolean DEFAULT false NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    nivel public."NivelServicio" DEFAULT 'BASICO'::public."NivelServicio" NOT NULL,
    "fechaInicio" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaFin" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 24665)
-- Name: sponsors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sponsors (
    id text NOT NULL,
    nombre text NOT NULL,
    nivel public."CategoriaSponsor" NOT NULL,
    "imagenUrl" text NOT NULL,
    descripcion text,
    "linkExterno" text NOT NULL,
    "fechaInicio" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaFin" timestamp(3) without time zone NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 24654)
-- Name: suscripciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suscripciones (
    id text NOT NULL,
    "servicioId" text NOT NULL,
    "duracionMeses" integer NOT NULL,
    monto numeric(10,2) NOT NULL,
    "metodoPago" text,
    "estadoPago" text DEFAULT 'pendiente'::text NOT NULL,
    "transaccionId" text,
    "fechaInicio" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaFin" timestamp(3) without time zone NOT NULL,
    activa boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 217 (class 1259 OID 24597)
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id text NOT NULL,
    email text NOT NULL,
    password text,
    nombre text NOT NULL,
    telefono text,
    avatar text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 219 (class 1259 OID 24614)
-- Name: usuarios_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios_roles (
    id text NOT NULL,
    "usuarioId" text NOT NULL,
    "roleId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3515 (class 0 OID 41121)
-- Dependencies: 227
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
36722768-a32b-4586-9be1-d58e78ca8f8e	50ed39048765c4d546142c666f5182586b0043c10b9dc16bb54d2c466ee7e8cc	2026-01-15 17:36:48.350606+00	20260113042530_init		\N	2026-01-15 17:36:48.350606+00	0
a0b55829-b792-4b27-98c8-a250538dfbc5	3f2c773c93745e56d20f55e045aee4b54586bd44ace505145de4fab635108988	2026-01-15 17:39:13.665642+00	20260115000000_production_sync		\N	2026-01-15 17:39:13.665642+00	0
bbb5ff42-cf9e-45ea-805c-07045af51643	7fcc5c0153f6d43b5840995b0d8b32cf5e5aec7a04d9ffd630dff457ce3ccb61	2026-01-16 17:39:08.199322+00	20260116173906_agregar_redes_sociales	\N	\N	2026-01-16 17:39:07.42679+00	1
\.


--
-- TOC entry 3510 (class 0 OID 24645)
-- Dependencies: 222
-- Data for Name: calificaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calificaciones (id, "servicioId", "usuarioId", estrellas, comentario, estado, "createdAt", "updatedAt") FROM stdin;
301ec6e0-1251-41c5-8525-09a2023054de	2a4dedc8-d776-487e-93b5-6ccd53219c68	ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c	5	El servicio de peluquería es excelente. Siempre están a la vanguardia, con un equipo profesional, muy buena onda y un ambiente acogedor. Además, son petfriendly, lo que hace que la experiencia sea aún más cómoda y cercana. Totalmente recomendados.	ACTIVO	2026-01-14 19:58:42.544	2026-01-14 19:58:57.137
f27fe170-590d-4569-9a8d-56de198bee69	c11d418b-1512-4629-b1fe-a52c1e6b675f	916ffe65-210b-4ba6-b48b-94e0cf8533d8	5	Gran creatividad y rapidez.	ACTIVO	2026-01-14 23:15:08.742	2026-01-14 23:21:46.643
f3b58922-6abb-469a-9d0d-95865f73443e	d9c99bb8-1c2c-4eb2-a471-dcb8a4fadaab	ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c	5	El servicio fue excelente. Rafael llegó antes de tiempo y tuvo la amabilidad de esperarme. Es un servicio que vale la pena contratar.	ACTIVO	2026-01-16 18:46:16.036	2026-01-16 18:46:27.679
\.


--
-- TOC entry 3508 (class 0 OID 24622)
-- Dependencies: 220
-- Data for Name: categoriaservicios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoriaservicios (id, nombre, slug, icono, orden, activo, "createdAt", "updatedAt") FROM stdin;
12dca568-dada-4897-b7c9-2ea9f02fcbfb	Gasfitería / Fontanería	gasfiteria	Droplets	0	t	2026-01-14 03:10:28.841	2026-01-14 03:10:28.841
63b1a696-a93d-4256-8939-f2c3cb1ba01a	Electricidad e Iluminación	electricidad	Zap	0	t	2026-01-14 03:10:29.126	2026-01-14 03:10:29.126
05becfc1-8bca-420e-aa53-e08c95c33e10	Cerrajería	cerrajeria	Key	0	t	2026-01-14 03:10:29.266	2026-01-14 03:10:29.266
39d1d677-0f23-4970-8f59-4df96b0afeb3	Carpintería y Mueblista	carpinteria	Hammer	0	t	2026-01-14 03:10:29.407	2026-01-14 03:10:29.407
cb351d96-f383-49cc-9fc6-248b9c4ddc82	Pintura y Papel Mural	pintura	Paintbrush	0	t	2026-01-14 03:10:29.548	2026-01-14 03:10:29.548
7af72c97-c3f4-4de2-97b0-5baf576adb65	Albañilería y Pisos	albanileria	HardHat	0	t	2026-01-14 03:10:29.689	2026-01-14 03:10:29.689
7e3faa20-6b32-4d1f-9903-3f5182342192	Vidriería y Aluminio	vidrieria	Square	0	t	2026-01-14 03:10:29.83	2026-01-14 03:10:29.83
ccb57ed9-1408-40c5-a441-f0d3e050f057	Reparación de Techos y Goteras	techos	Home	0	t	2026-01-14 03:10:29.97	2026-01-14 03:10:29.97
4d90c375-2886-4e55-9737-532ab838562e	Limpieza de Fachadas y Canaletas	limpieza-fachadas	Home	0	t	2026-01-14 03:10:30.112	2026-01-14 03:10:30.112
018271a9-e725-42a5-b273-506ae2a62829	Destape de Desagües	destapes	Droplets	0	t	2026-01-14 03:10:30.252	2026-01-14 03:10:30.252
43801a03-67e7-4955-950d-d8b9d3904372	Climatización	climatizacion	Thermometer	0	t	2026-01-14 03:10:30.394	2026-01-14 03:10:30.394
7f49774a-6e1b-4d28-b99d-2998ca82e13c	Reparación de Electrodomésticos	linea-blanca	Smartphone	0	t	2026-01-14 03:10:30.534	2026-01-14 03:10:30.534
f3420350-74a8-439a-8702-f85f0f637385	Limpieza de Hogar	limpieza-hogar	Sparkles	0	t	2026-01-14 03:10:30.675	2026-01-14 03:10:30.675
55a9abbe-5a6c-4928-a811-4da7d2b6296a	Limpieza de Tapices y Alfombras	limpieza-tapices	Waves	0	t	2026-01-14 03:10:30.816	2026-01-14 03:10:30.816
244a5fb9-635c-4945-b7e4-1329d1492b49	Fumigación y Control de Plagas	fumigacion	Bug	0	t	2026-01-14 03:10:30.956	2026-01-14 03:10:30.956
87c79093-1a63-44f9-bf75-355af9a68c7e	Jardinería y Paisajismo	jardineria	Leaf	0	t	2026-01-14 03:10:31.096	2026-01-14 03:10:31.096
65598093-4b1a-4f79-b32c-c9d11d79e378	Poda y Corte de Árboles	poda	Scissors	0	t	2026-01-14 03:10:31.236	2026-01-14 03:10:31.236
dc955861-f5ac-4b27-bea4-eda0b5ccafac	Mantención de Piscinas	piscinas	Waves	0	t	2026-01-14 03:10:31.377	2026-01-14 03:10:31.377
3bb54228-337f-4b8d-86c1-a72243afb185	Riego Automático	riego	Droplets	0	t	2026-01-14 03:10:31.518	2026-01-14 03:10:31.518
0e0f0b6f-b09c-47ca-94c4-e41d5f03a38f	Peluquería y Barbería	peluqueria	Scissors	0	t	2026-01-14 03:10:31.659	2026-01-14 03:10:31.659
ec6d6c58-abe7-47b7-bcc0-5f64942a8f13	Manicure y Pedicure	manicure	Sparkles	0	t	2026-01-14 03:10:31.8	2026-01-14 03:10:31.8
4e685c77-fa1a-4aea-881e-153a0af8e0e3	Maquillaje y Peinado	maquillaje	User	0	t	2026-01-14 03:10:31.941	2026-01-14 03:10:31.941
48885c5d-14b4-4316-a566-dfe0c731d43e	Depilación	depilacion	User	0	t	2026-01-14 03:10:32.081	2026-01-14 03:10:32.081
7371f611-b507-4582-8b56-067115691b33	Tratamientos Faciales y Corporales	estetica	Heart	0	t	2026-01-14 03:10:32.22	2026-01-14 03:10:32.22
aac89d1c-f480-4617-a1c9-a2a316c91892	Masajes	masajes	Hand	0	t	2026-01-14 03:10:32.362	2026-01-14 03:10:32.362
e6bc6af4-d0f6-4e34-b922-ee19d445f2c2	Enfermería a Domicilio	enfermeria	Syringe	0	t	2026-01-14 03:10:32.503	2026-01-14 03:10:32.503
2b828a73-34e1-4895-9e20-50107298a666	Cuidado de Adultos Mayores	cuidado-adultos	Heart	0	t	2026-01-14 03:10:32.644	2026-01-14 03:10:32.644
1797ca5c-61ba-426d-92e4-bd81331b0c92	Podología	podologia	Footprints	0	t	2026-01-14 03:10:32.785	2026-01-14 03:10:32.785
4a2b592a-9c54-4e55-a121-4253df80f584	Entrenador Personal / Yoga / Pilates	entrenamiento	Dumbbell	0	t	2026-01-14 03:10:32.925	2026-01-14 03:10:32.925
4e4189aa-7223-4dd9-b203-96da7fc32c11	Nutrición y Dietética	nutricion	Salad	0	t	2026-01-14 03:10:33.065	2026-01-14 03:10:33.065
2441848b-7d8d-4532-b16a-5749d5b8cecc	Peluquería y Baño de Mascotas	peluqueria-mascotas	Dog	0	t	2026-01-14 03:10:33.207	2026-01-14 03:10:33.207
1d049ee7-d40b-43f9-95b2-a18789d425ab	Veterinaria a Domicilio	veterinaria	Stethoscope	0	t	2026-01-14 03:10:33.347	2026-01-14 03:10:33.347
f7b5c729-b2e0-4109-acf8-1f103d3cebb7	Paseadores de Perros	paseadores	Dog	0	t	2026-01-14 03:10:33.489	2026-01-14 03:10:33.489
bba27ee4-18d7-4360-af9f-89b6d7f0823f	Cuidadores y Hotelería (Pet Sitting)	pet-sitting	Home	0	t	2026-01-14 03:10:33.629	2026-01-14 03:10:33.629
eb1b402d-f26e-4f41-a254-a020d4760228	Adiestramiento Canino	adiestramiento	Award	0	t	2026-01-14 03:10:33.768	2026-01-14 03:10:33.768
5b7242e4-2464-4ace-8de2-dae14cea0ef3	Lavado de Autos (Car Wash)	car-wash	Car	0	t	2026-01-14 03:10:33.909	2026-01-14 03:10:33.909
f27ae589-8432-4a7a-b1ec-cf3b32a56a36	Baterías y Carga	baterias	Battery	0	t	2026-01-14 03:10:34.191	2026-01-14 03:10:34.191
af2479da-e507-49e6-9d7e-a9f8b4447df3	Vulcanización y Neumáticos	vulcanizacion	Disc	0	t	2026-01-14 03:10:34.332	2026-01-14 03:10:34.332
164db591-d739-4324-85f0-a0568e88a5a8	Grúas y Remolque	gruas	Truck	0	t	2026-01-14 03:10:34.473	2026-01-14 03:10:34.473
5536328f-1595-446d-b93a-7e98bfc97755	Soporte Técnico Computacional	soporte-tecnico	Laptop	0	t	2026-01-14 03:10:34.614	2026-01-14 03:10:34.614
fd430eff-e0bc-469f-9909-478c11a6a595	Instalación de Cámaras y Alarmas	seguridad	Camera	0	t	2026-01-14 03:10:34.755	2026-01-14 03:10:34.755
2c647d6a-7e2a-4c2b-bc60-6070c867b5be	Redes, WiFi y Domótica	redes	Wifi	0	t	2026-01-14 03:10:34.896	2026-01-14 03:10:34.896
d1b64228-ff64-47d9-a36f-4c5e174ae7a3	Recuperación de Datos	recuperacion-datos	Database	0	t	2026-01-14 03:10:35.036	2026-01-14 03:10:35.036
315b6dde-7b9e-4b41-94c8-cb3a66287462	Banquetería y Catering	banqueteria	Utensils	0	t	2026-01-14 03:10:35.178	2026-01-14 03:10:35.178
2c503966-e5a2-4da7-b47c-4dff31794012	Tortas, Pastelería y Repostería	pasteleria	Cake	0	t	2026-01-14 03:10:35.319	2026-01-14 03:10:35.319
28294e26-696a-42be-832f-a2b5465c700f	Chef a Domicilio	chef	ChefHat	0	t	2026-01-14 03:10:35.46	2026-01-14 03:10:35.46
191e845c-c0e0-4479-b544-4f24fe08ff2c	Decoración y Ambientación	decoracion	Palette	0	t	2026-01-14 03:10:35.6	2026-01-14 03:10:35.6
e37e2ba5-acec-475f-95c6-515be2a29581	Animación y DJs	animacion	Music	0	t	2026-01-14 03:10:35.742	2026-01-14 03:10:35.742
c09d6cd3-244c-474e-a837-8917c082289b	Fotografía y Video de Eventos	fotografia	Camera	0	t	2026-01-14 03:10:35.883	2026-01-14 03:10:35.883
ad0c383c-8cbb-40ee-ba85-33443393ec6b	Reforzamiento Escolar	reforzamiento	GraduationCap	0	t	2026-01-14 03:10:36.023	2026-01-14 03:10:36.023
e24187eb-935a-4990-8c54-ce29b2a8dd35	Idiomas	idiomas	Languages	0	t	2026-01-14 03:10:36.163	2026-01-14 03:10:36.163
ca533a73-baf3-497e-801d-027ec4b608a6	Clases de Música e Instrumentos	clases-musica	Music	0	t	2026-01-14 03:10:36.304	2026-01-14 03:10:36.304
a9b587f2-3d86-4b24-8d76-3f3021733c47	Clases de Arte y Manualidades	clases-arte	Palette	0	t	2026-01-14 03:10:36.445	2026-01-14 03:10:36.445
9d16f2ae-19ef-43c7-8d25-62165c9f91da	Fletes y Mudanzas	fletes	Truck	0	t	2026-01-14 03:10:36.586	2026-01-14 03:10:36.586
cb47449a-52e4-44a8-b51c-f07558aa3451	Retiro de Escombros y Cachureos	escombros	Trash	0	t	2026-01-14 03:10:36.727	2026-01-14 03:10:36.727
14820ed4-c5a0-4809-a565-8affdb11b2fc	Mensajería y Encomiendas	mensajeria	Mail	0	t	2026-01-14 03:10:36.868	2026-01-14 03:10:36.868
a0736461-5f14-45c9-b9ac-106a582f4f19	Trámites y Gestoría	tramites	Clipboard	0	t	2026-01-14 03:10:37.008	2026-01-14 03:10:37.008
633b238a-3850-4739-85b4-a7c70cc7427d	Contabilidad y Finanzas	contabilidad	FileText	0	t	2026-01-14 03:10:37.15	2026-01-14 03:10:37.15
f61c41ff-d3ce-4b96-aa7f-91810acf1bf3	Asesoría Legal / Abogados	legal	Scale	0	t	2026-01-14 03:10:37.291	2026-01-14 03:10:37.291
26099d83-0b04-4eef-8b50-be178657fe95	Diseño Gráfico y Web	diseno	Monitor	0	t	2026-01-14 03:10:37.432	2026-01-14 03:10:37.432
b8a25d0d-9ead-4052-be33-41d6dd0c18a3	Hotel	hotel	Building	0	t	2026-01-14 03:10:37.575	2026-01-14 03:10:37.575
e38f39c1-d7be-497b-b7d4-af442fc6783e	Hospedaje / Cabañas	hospedaje	Home	0	t	2026-01-14 03:10:37.716	2026-01-14 03:10:37.716
b957e65f-da5a-425a-9763-470d2dd54575	Paseo en Botes / Navegación	paseo-botes	Ship	0	t	2026-01-14 03:10:37.996	2026-01-14 03:10:37.996
76b85395-7103-4f5f-8b9c-4b3a50558899	Trekking Guiado	trekking	Mountain	0	t	2026-01-14 03:10:38.136	2026-01-14 03:10:38.136
db7f8f0b-75bc-4190-a50a-9d1d8d8d49d1	Otros	otros	MoreHorizontal	0	t	2026-01-14 03:10:38.277	2026-01-14 03:10:38.277
1b3872c6-bcf7-43da-a002-75c0865f0f02	Informática	informtica	Monitor	0	t	2026-01-14 03:25:34.177	2026-01-14 03:25:34.177
6a64e105-4cf1-4f8a-b6d6-0da63cfc4ac9	Mantención industrial	mantencin-industrial	HardHat	0	t	2026-01-14 13:58:47.907	2026-01-14 13:58:47.907
0c8f227b-24ab-4365-a63c-5f3a6816fb26	Mecánica y Mantención Automotriz	mecanica	Wrench	0	t	2026-01-14 03:10:34.049	2026-01-14 14:00:08.534
cb760e4d-cdbc-4595-ab51-78195d33891c	Arriendo de Maquinaria	arriendo-de-maquinaria	Truck	0	t	2026-01-14 14:04:12.22	2026-01-14 14:04:12.22
c9843d42-099b-4450-8873-b701dcdb2904	Servicios Viales	servicios-viales	Truck	0	t	2026-01-14 14:04:35.669	2026-01-14 14:04:35.669
230fb679-962a-4010-bc15-f1034ffbd38b	Gimnasio	gimnasio	Dumbbell	0	t	2026-01-14 14:05:36.15	2026-01-14 14:05:36.15
96ba0e51-b260-466d-a774-e3bd1d7f51fe	Áridos	materiales-de-construccin	Truck	0	t	2026-01-14 14:07:21.816	2026-01-14 14:08:18.247
03b39e30-a960-4165-9886-a386e35c7645	Diseño y Creatividad Gráfica	diseo-y-creatividad-grfica	Sparkles	0	t	2026-01-14 14:10:19.915	2026-01-14 14:10:19.915
1adb9f2a-6c53-4cfe-8691-60e637438a4e	Gastronomía	gastronoma	Salad	0	t	2026-01-14 14:11:54.166	2026-01-14 14:11:54.166
f1719d34-61d4-4d43-8c0b-5305fb2e7a3e	Restaurante	restaurante	Salad	0	t	2026-01-14 14:13:26.068	2026-01-14 14:13:26.068
4cb5780d-2291-4c14-8339-bc82a7b8ed56	Salud	salud	Stethoscope	0	t	2026-01-14 14:14:31.241	2026-01-14 14:14:31.241
0fe85fb0-24c1-40d0-8d2f-9ae4079cfea7	Café y Pastelería	cafe-y-pastelera	ChefHat	0	t	2026-01-14 14:31:49.072	2026-01-14 14:32:05.565
ffef5db9-cb6e-4c8e-8731-5e2b00b6d28c	Tours y Excursiones	tours	Car	0	t	2026-01-14 03:10:37.855	2026-01-14 22:43:42.965
3ad5eee0-dbee-4411-a494-e2c4f7e2986d	Lavandería	lavandera	WashingMachine	0	t	2026-01-16 15:30:15.691	2026-01-16 15:30:15.691
\.


--
-- TOC entry 3514 (class 0 OID 32777)
-- Dependencies: 226
-- Data for Name: interacciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interacciones (id, tipo, "servicioId", "usuarioId", metadata, "createdAt") FROM stdin;
d0aacd69-b196-4967-9411-b8e212fa435a	VER_TELEFONO	d84c8b47-7e3f-4f32-8ccd-d7e795944284	ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c	\N	2026-01-14 22:25:35.146
4ab9b34e-3905-40f7-bb9d-2f626ff2c599	VER_EMAIL	d84c8b47-7e3f-4f32-8ccd-d7e795944284	ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c	\N	2026-01-14 22:25:36.032
08db2694-a802-4390-9df8-2ba82bfb461b	VER_TELEFONO	c11d418b-1512-4629-b1fe-a52c1e6b675f	\N	\N	2026-01-14 23:14:15.231
863cb232-3c0d-41df-8e18-acfcebc7c965	VER_EMAIL	c11d418b-1512-4629-b1fe-a52c1e6b675f	\N	\N	2026-01-14 23:14:16.857
4b0e9cb7-dcab-4b53-a5e8-7e2aa1804153	LLAMAR	3eb23981-5bbe-4996-b3b1-c82e4615141a	\N	\N	2026-01-15 00:41:41.459
fcdbc9d8-85fb-4e43-8523-5786f656cf8f	WHATSAPP	3eb23981-5bbe-4996-b3b1-c82e4615141a	\N	\N	2026-01-15 00:41:48.47
1cce1320-ae9c-41de-909f-83f0ced9eab5	VER_TELEFONO	3eb23981-5bbe-4996-b3b1-c82e4615141a	\N	\N	2026-01-15 00:41:59.946
262d3d9f-761c-4e16-8bf4-78ddb2cc2c9b	VER_EMAIL	3eb23981-5bbe-4996-b3b1-c82e4615141a	\N	\N	2026-01-15 00:42:01.288
38fef270-107a-445c-b47a-29d0bdd3ae71	VER_EMAIL	2a4dedc8-d776-487e-93b5-6ccd53219c68	\N	\N	2026-01-15 01:51:36.624
da23b530-a311-4aa2-964e-8efafc71c5fb	VER_TELEFONO	2a4dedc8-d776-487e-93b5-6ccd53219c68	\N	\N	2026-01-15 01:51:37.457
dd09ad03-4eb3-4dd3-95d7-6ac5f0f5c60e	WHATSAPP	2a4dedc8-d776-487e-93b5-6ccd53219c68	\N	\N	2026-01-15 01:58:28.805
f311e855-cf38-47cd-94a8-650d26c411b9	LLAMAR	dfdd5be4-2d76-4896-85a7-ad51f5b4c003	\N	\N	2026-01-15 04:14:38.47
67f1dd81-c131-4718-978f-a3e5e611c8ea	VER_TELEFONO	3eb23981-5bbe-4996-b3b1-c82e4615141a	\N	\N	2026-01-15 13:10:00.234
52098cdb-71b2-4d1c-9f39-1147a8679df6	VER_TELEFONO	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 13:28:25.839
bc7e00b5-37dd-43a9-b788-411491411974	VER_TELEFONO	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 16:31:25.714
682011e9-ffc3-4bec-ac69-b0dcae775c50	VER_EMAIL	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 16:31:27.798
54835ebf-3be6-4e23-8063-1496baec6902	LLAMAR	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 16:46:29.45
2657bdf4-fabe-47fa-b807-34e960b66878	WHATSAPP	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 16:46:31.882
7a46f151-565b-44ca-b8ce-47e97a6cd0ea	VER_TELEFONO	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 17:49:50.886
e4bf8a1a-91fb-4abb-b3d5-8d8522d27046	LLAMAR	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 17:50:00.51
62a812a7-55ed-4af7-bb4f-12ca46d351b7	LLAMAR	d805677a-3c2a-4a0f-ad3a-979cdf94720a	\N	\N	2026-01-15 18:54:32.208
68a17a1c-0492-4517-8e0d-846cf37c95a2	VER_TELEFONO	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-15 19:36:29.309
0101729a-17af-4438-85e5-39e321599ef8	LLAMAR	eee130b5-df79-4426-bc98-4b1a4bdd00a6	\N	\N	2026-01-15 20:38:20.618
45bb587e-0f7d-4dc4-ab76-b1c7835cffa9	LLAMAR	eee130b5-df79-4426-bc98-4b1a4bdd00a6	\N	\N	2026-01-15 20:45:27.134
ec65089f-1364-4260-be75-44ba5cbfdfc1	VER_EMAIL	d84c8b47-7e3f-4f32-8ccd-d7e795944284	\N	\N	2026-01-15 21:37:21.777
09a5caf5-faeb-485d-b55e-166b3e418b06	VER_TELEFONO	d84c8b47-7e3f-4f32-8ccd-d7e795944284	\N	\N	2026-01-15 21:37:22.621
e08e7ae4-a327-400f-b688-ca8a3c37302b	VER_EMAIL	58992e23-1606-48e5-b1cc-c5aba6efb7be	0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	\N	2026-01-16 14:46:43.734
3a05bf1f-f94c-46bd-82a4-9af2e72d68d1	VER_TELEFONO	58992e23-1606-48e5-b1cc-c5aba6efb7be	0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	\N	2026-01-16 14:46:45.779
bc71bd0b-1ff3-4da3-a4aa-9e27083058f8	VER_EMAIL	c11d418b-1512-4629-b1fe-a52c1e6b675f	\N	\N	2026-01-16 08:31:58.166
fe17ecbd-115c-45f8-8730-598850e56763	VER_TELEFONO	c11d418b-1512-4629-b1fe-a52c1e6b675f	\N	\N	2026-01-16 08:32:01.226
84a253f0-0ce4-4cc2-9293-2502b124fc44	LLAMAR	001ff859-04f8-4ad4-b0cf-aec35b6d2a37	\N	\N	2026-01-18 10:58:39.949
e5a1e3fe-a7e9-4070-ab19-df0d1905e1de	VER_TELEFONO	070a48fa-39e8-4572-a8c0-437b31f92e4e	0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	\N	2026-01-18 14:34:56.429
c83c20c5-fb54-45dd-9103-91c28f00bb1d	VER_EMAIL	070a48fa-39e8-4572-a8c0-437b31f92e4e	0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	\N	2026-01-18 14:34:58.074
78d0f0ce-8164-429f-9e35-f495bd0a8725	LLAMAR	070a48fa-39e8-4572-a8c0-437b31f92e4e	\N	\N	2026-01-18 14:59:18.708
bf0feb2f-83ce-419e-a1cb-1258ee439779	WHATSAPP	070a48fa-39e8-4572-a8c0-437b31f92e4e	\N	\N	2026-01-18 14:59:23.929
c0c162fd-7e5e-4ec2-80d3-ecaf5753d7bf	VER_TELEFONO	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-21 10:48:02.538
6204c3be-4066-4ce4-8c4c-4e9ab90ef64f	VER_TELEFONO	58992e23-1606-48e5-b1cc-c5aba6efb7be	\N	\N	2026-01-21 11:15:52.321
\.


--
-- TOC entry 3513 (class 0 OID 24675)
-- Dependencies: 225
-- Data for Name: precios_premium; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.precios_premium (id, "duracionMeses", precio, descripcion, activo, "createdAt", "updatedAt") FROM stdin;
191b1c15-adc4-4e1d-8830-3e1d81070043	1	9990.00	1 mes de servicio premium	t	2026-01-14 03:10:39.431	2026-01-14 03:10:39.431
a230631f-4635-4c37-9e8e-9f14adefe43b	3	27990.00	3 meses de servicio premium	t	2026-01-14 03:10:39.725	2026-01-14 03:10:39.725
776e9155-18c2-48f4-80f6-5933fe9abe18	6	54990.00	6 meses de servicio premium	t	2026-01-14 03:10:39.87	2026-01-14 03:10:39.87
c2a39bfa-5ac2-4dc1-a8ff-e42b02f0777e	12	99990.00	12 meses de servicio premium	t	2026-01-14 03:10:40.014	2026-01-14 03:10:40.014
\.


--
-- TOC entry 3516 (class 0 OID 57765)
-- Dependencies: 228
-- Data for Name: redes_sociales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.redes_sociales (id, "servicioId", tipo, url, "createdAt", "updatedAt") FROM stdin;
d5592515-17c0-4855-ae2d-38aeac37974c	8339592c-d700-4da8-a44a-b38fa11035a5	WEBSITE	https://www.odontosed.cl/	2026-01-16 19:09:55.353	2026-01-16 19:09:55.353
443c6365-c898-4030-8218-bd5e49a7a8a5	c11d418b-1512-4629-b1fe-a52c1e6b675f	WEBSITE	https://www.crowadvance.com/	2026-01-17 18:22:51.264	2026-01-17 18:22:51.264
58026a47-b4e2-4ad2-95ec-f28837e172ba	c11d418b-1512-4629-b1fe-a52c1e6b675f	FACEBOOK	https://www.facebook.com/advancecrow	2026-01-17 18:22:51.264	2026-01-17 18:22:51.264
91689a55-f604-4d48-a50b-82d386dd6576	c11d418b-1512-4629-b1fe-a52c1e6b675f	INSTAGRAM	https://www.instagram.com/crowadvance/	2026-01-17 18:22:51.264	2026-01-17 18:22:51.264
62ce87d3-4875-41df-a259-77ffa86a09a9	070a48fa-39e8-4572-a8c0-437b31f92e4e	WEBSITE	https://www.lavatu.cl	2026-01-18 14:34:01.407	2026-01-18 14:34:01.407
be9ed627-3b68-4669-8bf2-2fa397b51ed2	070a48fa-39e8-4572-a8c0-437b31f92e4e	INSTAGRAM	https://www.instagram.com/lavatu_castro/	2026-01-18 14:34:01.407	2026-01-18 14:34:01.407
d77ebc8c-42bd-403f-83f4-df0f3c2ec070	070a48fa-39e8-4572-a8c0-437b31f92e4e	FACEBOOK	https://www.facebook.com/lavatu.cl	2026-01-18 14:34:01.407	2026-01-18 14:34:01.407
84f64bec-d75e-427d-aa50-361017d48f2a	0fc2d02a-02de-4c51-b0cc-60ae84e811dc	WEBSITE	https://www.lavatu.cl	2026-01-18 14:53:49.561	2026-01-18 14:53:49.561
578755fe-55c9-4099-9e2c-23293e1c8a5d	0fc2d02a-02de-4c51-b0cc-60ae84e811dc	INSTAGRAM	https://www.instagram.com/lavatu_castro/	2026-01-18 14:53:49.561	2026-01-18 14:53:49.561
881e2097-9459-4e2f-9c87-c4587bfcbcc3	0fc2d02a-02de-4c51-b0cc-60ae84e811dc	FACEBOOK	https://www.facebook.com/lavatu.cl	2026-01-18 14:53:49.561	2026-01-18 14:53:49.561
c6e6133b-8ecd-41bc-a052-02e053caac22	1721d83e-679e-4c9f-af57-7f170d1bfe83	FACEBOOK	https://www.facebook.com/limpiezadecanonescastro/?locale=es_LA	2026-01-21 15:46:26.794	2026-01-21 15:46:26.794
\.


--
-- TOC entry 3506 (class 0 OID 24605)
-- Dependencies: 218
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, nombre, activo, "createdAt", "updatedAt") FROM stdin;
08bc1db3-0f4f-48fc-9db3-039fa52bcf8b	SuperAdministrador	t	2026-01-14 03:10:23.572	2026-01-14 03:10:23.572
2506dbe3-68a1-4570-bad5-873540371703	Usuario	t	2026-01-14 03:10:24.691	2026-01-14 03:10:24.691
\.


--
-- TOC entry 3509 (class 0 OID 24632)
-- Dependencies: 221
-- Data for Name: servicios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.servicios (id, "usuarioId", titulo, slug, "categoriaId", descripcion, precio, comuna, "imagenPrincipal", imagenes, "calificacionPromedio", "totalCalificaciones", destacado, activo, nivel, "fechaInicio", "fechaFin", "createdAt", "updatedAt") FROM stdin;
dfdd5be4-2d76-4896-85a7-ad51f5b4c003	5f714cc2-7a2f-4972-ace1-58a65b5faadf	Gráfica e Imprenta	grfica-e-imprenta-edel-grfica-e-imprenta	03b39e30-a960-4165-9886-a386e35c7645	Impresión de Pendones, Adhesivos, Windows Visión, Empavonados, Ecosolvente y UV	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768404341382-j5fic2wu4ah.jpg	{}	\N	0	t	t	PREMIUM	2026-01-14 15:27:41.071	2026-02-14 15:27:41.071	2026-01-14 15:25:41.954	2026-01-14 15:27:41.11
1c7382b3-6a02-44d3-b26d-ca905e7c3354	da060dd7-129b-49da-af13-d6c1536f3d40	Diseño impresiones y más 	diseo-impresiones-y-ms-jeniree-villamizar	db7f8f0b-75bc-4190-a50a-9d1d8d8d49d1	Somos una empresa dedicada al diseño gráfico, impresiones de Letreros, impresiones en adhesivo, rotulado vehicular, estampados y más. Con 6 años de servicio\r\n	25000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768403582541-kdoo9vqrubi.jpg	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768403590062-xc23lylzdi.jpg}	\N	0	t	t	PREMIUM	2026-01-14 15:13:11.337	2026-02-14 15:22:13.112	2026-01-14 15:13:11.34	2026-01-14 18:18:53.225
e944ef67-71d1-40e4-8c60-217587fe4f3d	c5bbd2bb-17be-4000-a8a1-f8823bd943a4	Chófer 	chfer-oscar-andres	ffef5db9-cb6e-4c8e-8731-5e2b00b6d28c	Traslados de pasajeros dentro y fuera de Castro, servicio confiable y seguro 	3000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768409765531-zibqmfhi9eb.jpg	{}	\N	0	f	t	BASICO	2026-01-14 16:56:06.208	2026-02-14 18:13:28.923	2026-01-14 16:56:06.212	2026-01-19 16:11:48.219
8339592c-d700-4da8-a44a-b38fa11035a5	eab4155f-20cb-4931-9dc5-34f45b9bf20b	Sedación Consciente: un servicio asociado a tu tratamiento odontológico	sedacin-consciente-un-servicio-asociado-a-tu-tratamiento-odontolgico-dr-victoria-lapaz	4cb5780d-2291-4c14-8339-bc82a7b8ed56	En ODONTOSED ofrecemos sedación consciente como un servicio asociado al tratamiento odontológico, pensado para pacientes que requieren una atención más tranquila y confortable. Esta técnica segura y controlada permite realizar procedimientos dentales reduciendo la ansiedad, el miedo y el estrés.\n\nDurante la atención, el paciente permanece consciente y colaborador, pero en un estado de profunda relajación, siempre bajo la supervisión de profesionales capacitados y en un entorno clínico seguro.\n\nLa sedación consciente es ideal para:\n\nPacientes con ansiedad o temor al tratamiento dental\n\nProcedimientos odontológicos prolongados o complejos\n\nPersonas con hipersensibilidad al dolor\n\nPacientes con malas experiencias odontológicas previas\n\nCuida tu salud oral con tranquilidad.\nAgenda tu hora y vive una experiencia odontológica segura y sin miedo.	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768417357821-dmm73wkfopv.png	{}	\N	0	f	t	BASICO	2026-01-14 19:02:38.46	2026-02-14 19:14:35.847	2026-01-14 19:02:38.462	2026-01-16 19:09:55.353
3eb23981-5bbe-4996-b3b1-c82e4615141a	69257d2f-05a5-4c26-8f24-4e24faf4a4f5	Pizzeria - pizza XL 50 CM - New york style - pizza al corte!	pizzeria-pizza-xl-50-cm-new-york-style-pizza-al-corte-respect-the-pizza	1adb9f2a-6c53-4cfe-8691-60e637438a4e	"Respect The Pizza | New York Style en el Sur de Chile Pizzas hechas con carácter, masa auténtica estilo NY, ingredientes brutales y dedicación real. Aquí no competimos: marcamos la cancha. Cada slice es grande, sabroso y con flow callejero. Si quieres pizza de verdad, respeta la tuya… y respeta la nuestra."	4000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768422667654-f83srt8fh7p.jpeg	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768422668520-za37gwkt2rj.jpeg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768422669282-ejh11m1z45r.jpeg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768422669964-qmqcro2lfj.jpeg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768422670814-vex2ftx0e6g.jpeg}	\N	0	t	t	PREMIUM	2026-01-14 20:31:11.278	2026-02-14 20:44:49.387	2026-01-14 20:31:11.28	2026-01-14 20:44:49.388
58992e23-1606-48e5-b1cc-c5aba6efb7be	5f4306df-4148-4c85-b752-e2a56d7a4f15	Gasfiter Preparado 	gasfiter-preparado-marco-fuenzalida	12dca568-dada-4897-b7c9-2ea9f02fcbfb	Poseo más de 15 años de experiencia en el rubro y trabajo los materiales de pvc, ppr, cobre y en este último soldadura a la plata si es necesario, además reparo calefont y todos mis trabajos son garantizados 	25000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768418422468-glqln736kcf.jpeg	{}	\N	0	t	t	PREMIUM	2026-01-14 19:20:24.253	2026-02-14 21:48:32.553	2026-01-14 19:20:24.26	2026-01-14 21:48:32.554
d805677a-3c2a-4a0f-ad3a-979cdf94720a	c5648f92-c9a1-48a4-8670-5756d4903676	Profesor de educación musical 	profesor-de-educacin-musical-felipe-francisco-lobos-roa	ca533a73-baf3-497e-801d-027ec4b608a6	Hola, Soy profesor de Música, con mas de veinte años de experiencia en educación parvularia, básica, media y universitaria.\r\nEnseño teoría musical occidental. \r\nInstrumentos como el Piano, Guitarra, Flauta dulce, Charango, Bajo.\r\n\r\n\r\n	10000.00	Ancud	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768419665896-t9qt4tm98go.jpg	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768419668177-8d13lo871es.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768419669089-3iy78fx2hro.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768419670244-em8gdl9ecii.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768419670987-nktj9lqyxwm.jpg}	\N	0	f	t	BASICO	2026-01-14 19:41:12.1	2026-02-14 19:48:53.157	2026-01-14 19:41:12.102	2026-01-19 16:11:05.295
d84c8b47-7e3f-4f32-8ccd-d7e795944284	6e2ec856-7a42-46b5-ace2-d853e3937348	ALQUIMET SPA	alquimet-spa-claudio-mella-chico	6a64e105-4cf1-4f8a-b6d6-0da63cfc4ac9	Somos una empresa dedicada a la fabricación de estructuras metálicas de todo tipo tanto para particulares como para empresas, además realizamos todo tipo de proyectos en acero inoxidable, acero al carbono, aluminio, cañerias y tuberías, muebles con diseños personalizados y estructuras para el hogar o edificios	45000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768427169915-ar2airpkxo6.jpg	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768427171999-b1f7fstkzd.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768427173225-bqekf3yh9g.jpg}	\N	0	f	t	BASICO	2026-01-14 21:46:13.668	2026-02-14 21:46:35.109	2026-01-14 21:46:13.672	2026-01-19 16:12:13.058
b67705be-575f-4305-b44e-813ed36cf441	24da84f4-b0e9-4253-9711-c2e146360354	Odontóloga 	odontloga-gabriela-muoz-flores	4cb5780d-2291-4c14-8339-bc82a7b8ed56	Consultar en número especificado por Dra. Gabriela Muñoz F.\r\n\r\nServicios dentales disponibles:\r\nEvaluaciones\r\nLimpiezas\r\nBlanqueamiento\r\nRestauraciones\r\nPrótesis dentales \r\nCoronas\r\nIncrustaciones \r\n\r\nImágenes en galería 100% reales de tratamientos a mis pacientes!!\r\n\r\nAgenda tu hora 😁	13000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768445068542-c47y6ng57rl.webp	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768445069527-cfvk8qi5are.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768445070275-mqz0ftu6g7p.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768445071189-ghdckngz3k5.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768445074318-n6yd9mmtey.jpg}	\N	0	f	t	BASICO	2026-01-15 02:44:35.081	2027-01-15 02:44:35.081	2026-01-15 02:44:35.087	2026-01-15 02:44:35.087
1b9eb113-adf6-4957-8276-3f61c10de878	512ed163-2f42-44e8-b8e4-415637ed319f	Médico Veterinario a Domicilio	mdico-veterinario-a-domicilio-gerardo-andrs-morales-chvez	1d049ee7-d40b-43f9-95b2-a18789d425ab	Ofrezco atención veterinaria profesional en la comodidad de tu hogar, brindando un servicio personalizado, ético y centrado en el bienestar integral de tu mascota. La atención a domicilio reduce el estrés asociado a traslados y salas de espera, permitiendo una evaluación médica tranquila y un manejo respetuoso, especialmente en pacientes geriátricos, con movilidad reducida, animales reactivos o convalecientes. Mis servicios incluyen:\n- Consulta clínica general\n- Medicina preventiva\n- Atención de pacientes geriátricos y crónicos\n- Procedimientos menores\n- Certificados sanitarios\n- Orientaciones sanitarias\n- Eutanasias humanitarias\n\nMi atención se basa en los principios de bienestar animal, tenencia responsable y enfoque Una Salud, promoviendo no solo la salud de las mascotas, sino también la de las personas y el entorno.\n\n📍 Atención a domicilio: coordinada previamente, con horarios flexibles.\n📞 Consultas y agendamiento: +56 9 6642 1472\n\n	20000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768505254518-1zyrvphk4vf.jpg	{}	\N	0	f	t	BASICO	2026-01-15 19:27:35.302	2027-01-15 19:27:35.302	2026-01-15 19:27:35.303	2026-01-15 19:28:21.206
2a4dedc8-d776-487e-93b5-6ccd53219c68	3c2eeb6b-5fd7-413d-a8ff-9aeddb3019f8	Barberia Neoclásica Profesional	barberia-neoclsica-profesional-industria-crew-	0e0f0b6f-b09c-47ca-94c4-e41d5f03a38f	💈✂ En Industria CREW no solo vienes a cortarte el cabello, vienes a vivir una experiencia distinta.\r\n\r\n📍 Estamos ubicados en pleno centro de Castro, el corazón de Chiloé ❤‍🔥, con un espacio neo clásico e industrial que combina lo mejor de lo tradicional ⚜ y lo moderno 🚀.\r\n\r\nAquí dominamos ambos mundos: los cortes clásicos de siempre 🧔 y las tendencias más actuales que marcan estilo 🔥.\r\n\r\n\r\n\r\n🕘 Abrimos todos los días de 9:00 a 20:00, en un ambiente que vibra con buena música 🎶, películas 🎬 y una energía única ⚡ que nos convierte en más que una barbería: somos un punto de encuentro 🤝.\r\n\r\n\r\n\r\n👑 Nuestro equipo de barberos tiene años de experiencia ✨ y está comprometido en entregar resultados de alto nivel 💯, usando siempre productos premium 🧴.\r\n\r\nCada corte, cada detalle y cada servicio reflejan lo que somos: profesionales apasionados 💪 por nuestro oficio.\r\n\r\n\r\n\r\n🥇 Por todo esto nos consolidamos como la barbería número 1 de Castro y un referente del sur de Chile 🌎.\r\n\r\n\r\n\r\n	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768418022084-kdm2xzzygzk.jpg	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768418022816-65fkku4b157.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768418023736-oowury9ym1n.jpg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768418024736-dvwwo7vnh6w.jpg}	5.0	1	f	t	BASICO	2026-01-14 19:13:45.234	2026-02-14 19:14:33.573	2026-01-14 19:13:45.237	2026-01-15 03:27:44.91
74607e64-118d-4b58-b800-03a336d2ab85	be05d338-6f69-4ec0-86e4-cddf174ade70	Podologo clínico 	podologo-clnico-miguel-ignacio-aguilar-aguilar	1797ca5c-61ba-426d-92e4-bd81331b0c92	Podologia Domiciliaria dentro de castro.	20000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768506654993-rtmnshhi4we.png	{}	\N	0	f	t	BASICO	2026-01-15 19:50:55.604	2027-01-15 19:50:55.604	2026-01-15 19:50:55.605	2026-01-15 19:50:55.605
eee130b5-df79-4426-bc98-4b1a4bdd00a6	d2b15204-bc26-426e-b74b-f2690b14ac06	peluqueria canina  certificada	peluqueria-canina-certificada-burbujaspeluqueria-canina	2441848b-7d8d-4532-b16a-5749d5b8cecc	En @peluqueriacanina_burbujas encontraras nuestros trabajos hechos con amor y dedicación a cada amiguito perruno que nos visita\r\nofrecemos corte de pelo en cuerpo, corte sanitario (zona genital) emparejamiento de cara, baños (cosméticos, medicados, hidromasajes) y secado, corte de uñas, limpieza de oídos.	25000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768509462149-zc2b50red1q.jpeg	{}	\N	0	f	t	BASICO	2026-01-15 20:37:43.489	2027-01-15 20:37:43.489	2026-01-15 20:37:43.49	2026-01-15 20:37:43.49
2bc36db4-1309-4cf1-aca4-d04372d3c331	7c34534c-71ed-4b96-bedb-4cf26c1a5c00	Técnico en estufas a Pellet 	tcnico-en-estufas-a-pellet-marco-miranda	43801a03-67e7-4955-950d-d8b9d3904372	CRISANT\r\nTécnico certificado con los siguientes servicios.\r\n•Instalación🔥\r\n•Mantencion🔥\r\n•Servicio técnico 🔥\r\n•Restauración 🔥\r\n•Servicio en todo Chiloé 🔥	70000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768526394452-acw8dxvx1wb.jpeg	{}	\N	0	f	t	BASICO	2026-01-16 01:19:55.047	2027-01-16 01:19:55.047	2026-01-16 01:19:55.048	2026-01-16 01:19:55.048
d9c99bb8-1c2c-4eb2-a471-dcb8a4fadaab	7e94fa07-108a-4f60-a2b2-d3435c83338f	Servicio de taxis y delivery	servicio-de-taxis-y-delivery-rafael-rodrguez	9d16f2ae-19ef-43c7-8d25-62165c9f91da	Servicios ejecutivo y de compras de cualquier producto.	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768489540054-z8i2sme1lkk.jpg	{}	5.0	1	f	t	BASICO	2026-01-15 15:05:40.757	2027-01-15 15:05:40.757	2026-01-15 15:05:40.759	2026-01-16 18:46:27.715
001ff859-04f8-4ad4-b0cf-aec35b6d2a37	57f7d7a1-66eb-4231-9d1c-4f687a8aa134	Implantología	implantologa-luis-asem	4cb5780d-2291-4c14-8339-bc82a7b8ed56	Especialista en implantología dental en Castro. Recupera tu sonrisa y funcionalidad con una solución fija, segura y estética. A través de nuestros implantes dentales, te garantizamos un tratamiento de alta calidad, totalmente personalizado a tus necesidades. Agenda tu evaluación hoy.	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768445646676-ch2hnkeh7sq.JPG	{}	\N	0	f	t	BASICO	2026-01-15 02:54:07.492	2026-02-15 03:13:09.256	2026-01-15 02:54:07.494	2026-01-19 16:10:58.458
1721d83e-679e-4c9f-af57-7f170d1bfe83	f2df8f5b-bc93-462c-8b9a-0ba908883cd9	Limpieza de Caños y Gasfitería	limpieza-de-caos-y-gasfitera-carlos-velsquez-subiabre	12dca568-dada-4897-b7c9-2ea9f02fcbfb	Limpieza de estufas a leña, cocinas a leña, ductos de estufas a pellet, gasfitería domiciliaria, instalación de estanques de agua y termos eléctricos de agua.	15000.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1769010385340-61z5es3agmo.png	{}	\N	0	f	t	BASICO	2026-01-21 15:46:26.793	2027-01-21 15:46:26.793	2026-01-21 15:46:26.794	2026-01-21 15:46:26.794
c11d418b-1512-4629-b1fe-a52c1e6b675f	ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c	Desarrollo Web y Soluciones Digitales para tu Negocio	desarrollo-web-y-soluciones-digitales-para-tu-negocio-edgardo-ruotolo	1b3872c6-bcf7-43da-a002-75c0865f0f02	Transformamos tu negocio con tecnología de punta. Ofrecemos desarrollo web, consultoría informática y diseño de marca. Nos encargamos de la parte técnica para que tú te enfoques en crecer. ¡Hablemos!	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768361170017-ko9a2sx21h.png	{https://iz3fjv7vcfowww2p.public.blob.vercel-storage.com/services/1768362080962-s10v2xue84h.jpg,https://iz3fjv7vcfowww2p.public.blob.vercel-storage.com/services/1768362082937-43syduzyat1.jpg,https://iz3fjv7vcfowww2p.public.blob.vercel-storage.com/services/1768362083722-1r4k79zas1i.jpg,https://iz3fjv7vcfowww2p.public.blob.vercel-storage.com/services/1768362084675-145eeu2addjd.jpg}	5.0	1	f	t	BASICO	2026-01-14 03:26:10.386	2026-02-14 03:35:57.973	2026-01-14 03:26:10.387	2026-01-17 18:22:51.264
070a48fa-39e8-4572-a8c0-437b31f92e4e	0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	Lavandería LavaTú | Especialistas en Plumones, Sábanas, Frazadas y Carga Familiar	lavandera-lavat-especialistas-en-plumones-sbanas-frazadas-y-carga-familiar-jaime-cifuentes	3ad5eee0-dbee-4411-a494-e2c4f7e2986d	¿Tu ropa no se seca? Nosotros nos encargamos. En LavaTú, somos la solución profesional en Castro para el cuidado de tus prendas. Olvídate de la humedad y recupera tu tiempo.\r\n\r\nNuestros Servicios Destacados:\r\n\r\n✅ Especialistas en Ropa de Cama: Lavado y secado perfecto de Cobertores, Plumones, Sábanas y Frazadas (de 1 a 2 plazas y King).\r\n\r\n✅ Lavado y Secado por Carga: Servicio rápido para tu ropa de uso diario.\r\n\r\n✅ Aromatización Premium: El toque final que tus prendas merecen.\r\n\r\n✅ Servicio a Hotelería y Cabañas: Calidad industrial para tu negocio.\r\n\r\n📍 Ubicación: Gamboa 590, Castro 🚀 Servicio Rápido y Garantizado.\r\n\r\n🎁 BENEFICIO EXCLUSIVO CHILOÉ SERVICIOS: Menciona que nos viste en este portal y obtén GRATIS un upgrade de Aromatización Premium en tu primer lavado de Cobertor o Plumón.	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768746828132-sbktvgxo9u.png	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768746829918-q1shei9te1.png,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768746833429-9z4cuie60w6.png,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768746836633-44cj01ji9bm.png,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768746840888-jvlmgoir7z.png}	\N	0	f	t	BASICO	2026-01-18 14:34:01.405	2027-01-18 14:34:01.405	2026-01-18 14:34:01.407	2026-01-18 14:34:01.407
0fc2d02a-02de-4c51-b0cc-60ae84e811dc	0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	Spa de Zapatillas & Recuperación Textil | LavaTú	spa-de-zapatillas-recuperacin-textil-lavat-lavandera-lavat	3ad5eee0-dbee-4411-a494-e2c4f7e2986d	No las botes, ¡recupéralas! Tus zapatillas como nuevas otra vez. Somos los primeros en limpieza especializada de zapatillas Castro y Chiloé. Usamos técnicas manuales y productos profesionales para no dañar tus materiales.\r\n\r\n¿Qué podemos recuperar?\r\n\r\n👟 Limpieza Profunda de Zapatillas: Desde deportivas hasta urbanas.\r\n\r\n✨ Blanqueamiento de Suelas: Eliminamos el tono amarillo por oxidación.\r\n\r\n🛡️ Tratamiento de Gamuza y Cuero: Cuidado delicado para materiales sensibles.\r\n\r\nNo arriesgues tus zapatillas en la lavadora de casa. Déjalas en manos de expertos.\r\n\r\n🎁 BENEFICIO EXCLUSIVO CHILOÉ SERVICIOS: Menciona este anuncio al dejar tus pares y recibe gratis la aplicación de repelente de líquidos en tus zapatillas.	0.00	Castro	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768748025000-en6u4rd42cr.jpeg	{https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768748025976-5lkfxgtr23j.jpeg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768748026674-tvdoeq3qopt.jpeg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768748027916-fjarvqzknfq.jpeg,https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/services/1768748029088-u472nbii2tc.jpeg}	\N	0	f	t	BASICO	2026-01-18 14:53:49.559	2027-01-18 14:53:49.559	2026-01-18 14:53:49.561	2026-01-18 14:53:49.561
\.


--
-- TOC entry 3512 (class 0 OID 24665)
-- Dependencies: 224
-- Data for Name: sponsors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sponsors (id, nombre, nivel, "imagenUrl", descripcion, "linkExterno", "fechaInicio", "fechaFin", activo, "createdAt", "updatedAt") FROM stdin;
e0f202bf-c2f1-4a23-8625-0c49a7577f99	Dra Carolina Aros	SENIOR	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/sponsors/1768586708652-6kla824gjep.jpg	Dentista y Estética Facial ProfesionaL\nEN CHILOÉ Y PUERTO MONTT\nCLÍNICA Dra. Carolina Aros	https://carolinaaros.cl/	2026-01-16 00:00:00	2026-02-16 00:00:00	t	2026-01-16 18:05:11.074	2026-01-16 18:07:56.949
\.


--
-- TOC entry 3511 (class 0 OID 24654)
-- Dependencies: 223
-- Data for Name: suscripciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suscripciones (id, "servicioId", "duracionMeses", monto, "metodoPago", "estadoPago", "transaccionId", "fechaInicio", "fechaFin", activa, "createdAt", "updatedAt") FROM stdin;
323bdf66-665d-4890-af51-1376c37e061a	dfdd5be4-2d76-4896-85a7-ad51f5b4c003	1	9990.00	mercadopago	completado	141335411987	2026-01-14 15:27:41.071	2026-02-14 15:27:41.071	t	2026-01-14 15:27:40.789	2026-01-14 15:27:41.106
\.


--
-- TOC entry 3505 (class 0 OID 24597)
-- Dependencies: 217
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, email, password, nombre, telefono, avatar, "createdAt", "updatedAt") FROM stdin;
57f7d7a1-66eb-4231-9d1c-4f687a8aa134	luisasems@gmail.com	$2b$10$dYisN7Sfw4KZziqTDIhVteLsmViF2mrrOlHkhrzifEUqTnmW10XOG	Luis Asem	+56995940265	\N	2026-01-15 02:45:32.105	2026-01-15 02:45:32.105
ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c	edgardoruotolo@gmail.com	$2b$12$9s.IHEnfLoGi3N8bYBWQz.v9Ogsn/F9UaVaWewcApVFtGVXGgmYv2	Edgardo Ruotolo	+56967553841	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/users/ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c-1768360430097-BB4oooxFjSHQg66GC4pilVMArYRhWW.png	2026-01-14 03:10:25.616	2026-01-14 03:13:50.208
39998fe5-2d93-4f36-a290-0f3eccbf8ba9	camila.antonietaz@gmail.com	$2b$10$oNagbQUppSkLafZzF/Mnku6uPI85S9FI0nkdlIYG76chKw/elJeH2	Camila	\N	\N	2026-01-14 14:56:00.112	2026-01-14 14:56:00.112
da060dd7-129b-49da-af13-d6c1536f3d40	arq.jen29@gmail.com	$2b$10$h2mgowmzUJqIquw.rfmeUO9SdrX5ePE8VzhK98sn4FKcK..6ANbLu	Jeniree Villamizar 	+56922123102	\N	2026-01-14 14:20:06.823	2026-01-14 15:18:02.793
5f714cc2-7a2f-4972-ace1-58a65b5faadf	redelbarria@hotmail.com	$2b$10$teq5.rldZV6QB1/TdaViuuQI3QXFkOY8nottqqO9bz4BHxY7Eqy6u	Edel Gráfica e Imprenta	+56 9 8282 3772	\N	2026-01-14 15:21:52.498	2026-01-14 15:21:52.498
c5bbd2bb-17be-4000-a8a1-f8823bd943a4	oa45992@gmail.com	$2b$10$TFq040SEPMkqHDg2jExgUeLW/m3AoJZ70tTjTDOryztrODPs0mc9i	Oscar Andres 	+56971317212	\N	2026-01-14 16:52:06.939	2026-01-14 16:52:06.939
eab4155f-20cb-4931-9dc5-34f45b9bf20b	dravictoria.lapaz@gmail.com	$2b$10$1Yr3o3ZWhkajoFRC93uiX.Vk5G2SnOxrW6J589FmzLaKxzmseohnK	Dr. Victoria Lapaz	+56 9 4088 3680	\N	2026-01-14 18:57:08.714	2026-01-14 18:57:08.714
5f4306df-4148-4c85-b752-e2a56d7a4f15	construccionesguarello@gmail.com	$2b$10$thec2bA1CSj9BirWUV9CKe7Kk.PCwOmmCzrEGEkNXI/w0q1MIgIDO	Marco Fuenzalida 	+56997771341	\N	2026-01-14 19:12:46.952	2026-01-14 19:24:26.554
c5648f92-c9a1-48a4-8670-5756d4903676	lobosroa@gmail.com	$2b$10$1TkdFP/Qhmk6B553sfrxPOYh1uT30LmnOugO7TpiByQC9uIKyhp6i	Felipe Francisco Lobos Roa 	+56965278445	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/users/c5648f92-c9a1-48a4-8670-5756d4903676-1768420201210-lL9EUMimT9DT6i7TWtvi94dAt4WsLU.png	2026-01-14 19:25:55.969	2026-01-14 19:50:27.782
67f938b2-b4b8-4e13-ae10-41bee5ee2bff	luis@nexusinnova.com	$2b$10$zD7.WhTDPzhJ.mft16/z..1LGRV6EZrDliREaQr1ziuPh/w.MQ59K	Nexus Innova 	+14847958989	\N	2026-01-14 20:27:19.494	2026-01-14 20:27:19.494
33b29a90-86af-4d79-bfbe-b11c9e447ff3	lorca.andres@gmail.com	$2b$10$wrcrtoeMev0jyX9Xz4bP/e8AuEuHVobfAPNCo4Ld/pmbjlvw5A.EC	Andrés Lorca	+56998926960	\N	2026-01-14 21:36:22.105	2026-01-14 21:36:22.105
69257d2f-05a5-4c26-8f24-4e24faf4a4f5	respectthepizza1@gmail.com	$2b$10$XaHFx9pn8QJ9ZwHweJfDkOIU.3WLxWzI7U2Y7MbCTeF6Y.IeQAcYe	Respect The Pizza 	+56 9 6436 7946	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/users/69257d2f-05a5-4c26-8f24-4e24faf4a4f5-1768422188040-sLzhcbozJtRiVLffeq3n9XPKrR61HV.png	2026-01-14 19:54:51.171	2026-01-15 14:55:14.752
3c2eeb6b-5fd7-413d-a8ff-9aeddb3019f8	industria.chiloe@gmail.com	$2b$10$FCkRuCVN.10RJIEYvFx6oOTv3dUdgrdg5Mjc4/BoGUMlR/P0O9Afa	Industria Crew 💈	+56 9 6859 5375	\N	2026-01-14 19:11:02.04	2026-01-15 14:55:29.687
7e94fa07-108a-4f60-a2b2-d3435c83338f	rrrc1968@gmail.com	$2b$10$R18t04KT3Ol5oTxATdm.p.HzXRXygA2VSikPaS5oFXqqnHBGU1oBO	Rafael Rodríguez 	968370861	\N	2026-01-15 14:58:08.279	2026-01-15 14:58:08.279
6e2ec856-7a42-46b5-ace2-d853e3937348	cm.alquimetspa@gmail.com	$2b$10$6kjKviZ1QfqtMsxlEBa9UO96oFEGkQkb5BSiN4q8jIs4Br2SMAVCS	ALQUIMET SPA	930978968	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/users/6e2ec856-7a42-46b5-ace2-d853e3937348-1768428025423-l2tTGn4NZbeHlSA5okzuae4MmkO9Ss.png	2026-01-14 21:36:47.565	2026-01-14 22:00:25.551
916ffe65-210b-4ba6-b48b-94e0cf8533d8	millonymil2025@gmail.com	$2b$10$/m7yMlJLru1J1vtYFJ2IkeGqv79emysAk3NNKCKrxUDdIw8jBIEuS	Román Rique		\N	2026-01-14 23:15:08.349	2026-01-14 23:40:19.053
24da84f4-b0e9-4253-9711-c2e146360354	gaabriela.mf@gmail.com	$2b$10$Gpi/.b.kF.dMmEWQw99LLeTyVjaEye784C1QZ0RgRApifF8YwHDia	Gabriela Muñoz Flores	+56964603616	\N	2026-01-15 02:23:04.052	2026-01-15 02:23:04.052
4570c2e4-7fe1-43dc-9edd-bbd6c1c14c65	controlvetchile@gmail.com	$2b$10$APUFim.SWPKdJdOG0URhgeRac8oIeHrhxdQ22DdmS8CUEUAmAbjsK	Erika Yanez del Solar 	+56987745393	\N	2026-01-15 17:11:39.745	2026-01-15 17:11:39.745
512ed163-2f42-44e8-b8e4-415637ed319f	gerardo.morchav@gmail.com	$2b$10$JQZPTmUhvcYyx1sqp96HmubtHh6aIXlSy1MXlvEyUfrhH1wtL81Su	Gerardo Andrés Morales Chávez	966421472	\N	2026-01-15 18:55:37.677	2026-01-15 18:55:37.677
be05d338-6f69-4ec0-86e4-cddf174ade70	miguel.aguilar.agui@gmail.com	$2b$10$ewmhPsjKr2EtyGBok3Gbq.URXc2uUa0xdxn4zDtw4PgpFW.DybpeO	Miguel Ignacio Aguilar Aguilar 	+56948107781	\N	2026-01-15 19:49:01.091	2026-01-15 19:59:23.703
d2b15204-bc26-426e-b74b-f2690b14ac06	spapeluqueriacaninaburbujas@gmail.com	$2b$10$AE9qjaB3MTguDcP//sZyuO6zU73Hmf.9b1G2qqe0hkMWQvAbq42I.	BURBUJAS(peluqueria canina)	+56 652532654	\N	2026-01-15 20:10:03.651	2026-01-15 20:10:03.651
f432c163-5bce-40d2-a09b-c21b2c5fc70c	fullmascotaschiloe@gmail.com	$2b$10$FQiNVraW80VJ9ccJp.Cj2eYGjbhOoJFsY4lBeaqnQ1LmTNpO59.D2	Full Bigotes	+56971772430	\N	2026-01-15 22:33:12.102	2026-01-15 22:33:12.102
75270371-a8c1-4056-9ec2-27d1b4849b51	dannyfranco@gmail.com	$2b$10$IBYgqElNqPJByY7ntEuNSePWblBRlj5xc5zQOfBcEzcMpv20RMruu	Danny Franco	987241101	https://5dkg8auvdlpsgblz.public.blob.vercel-storage.com/users/75270371-a8c1-4056-9ec2-27d1b4849b51-1768522868422-1pTc21mKxPPXC02LInu2c2GlhfKSgq.png	2026-01-14 19:02:35.78	2026-01-16 00:21:08.805
7c34534c-71ed-4b96-bedb-4cf26c1a5c00	chmmiranda07@gmail.com	$2b$10$KpS/mGiEXYTbcsxE0MSN4enqknymjvzjCG.5g03OY60WKMx060z0i	Marco Miranda 	936108526	\N	2026-01-16 01:14:57.957	2026-01-16 01:14:57.957
b4f90838-15dd-4ad1-8c68-c3a5c3a7f9cc	d.andresyanez@gmail.com	$2b$10$iCo4lpu9wSY7tU7x4p978OlVyqnl/PIL3oLu0Lj8w4DLJp9BQAJ5q	Diego Andrés Yáñez Butkovich 	+56958738991	\N	2026-01-16 22:50:11.558	2026-01-16 22:50:11.558
0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	contacto@lavatu.cl	$2b$10$WVicrs3pJa/jrfn7yWQjceSPqtfOCeoT1WQYxBYKu4p7TGklOhZ82	Lavandería LavaTú	+56956993082	\N	2026-01-16 00:39:56.152	2026-01-18 14:36:38.71
1b9fd83b-bc79-4e1b-87c1-eb45eeb17497	javier.cheuque31@gmail.com	$2b$10$E7DGUKmWCtIqX7WBsqYpMOEbMtNJm8.dEMrk8Vd6IEZE.tO6evTJy	Javier Esteban Cheuque Cheuque	+56981279327	\N	2026-01-18 15:30:02.353	2026-01-18 15:30:02.353
f2df8f5b-bc93-462c-8b9a-0ba908883cd9	velasquezcortes86@gmail.com	$2b$10$ujJ7ei1nlUWQ7GHX5pfpseV6Uw7Iu1yu8REj0H8k6.ApsPIoR0rMO	Carlos Velásquez Subiabre	+56950904709	\N	2026-01-21 15:38:06.95	2026-01-21 15:38:06.95
\.


--
-- TOC entry 3507 (class 0 OID 24614)
-- Dependencies: 219
-- Data for Name: usuarios_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios_roles (id, "usuarioId", "roleId", "createdAt") FROM stdin;
69f305a6-848b-49ad-885d-25a8b251582b	ca0fcbc0-5e55-40a1-ae56-6fb3d57b1f6c	08bc1db3-0f4f-48fc-9db3-039fa52bcf8b	2026-01-14 03:10:26.729
4eec7624-4c75-45ed-8be5-7e8316f0e039	da060dd7-129b-49da-af13-d6c1536f3d40	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 14:20:06.823
96f4c441-dada-4dc9-90bb-cced8bf5642a	39998fe5-2d93-4f36-a290-0f3eccbf8ba9	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 14:56:00.112
0747b37e-90df-4dcb-b57d-f1822985d951	5f714cc2-7a2f-4972-ace1-58a65b5faadf	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 15:21:52.498
90be7f8f-481a-49f9-8a42-67176b92badf	c5bbd2bb-17be-4000-a8a1-f8823bd943a4	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 16:52:06.939
b5cc2983-9921-45b2-8b67-fce5c1208574	eab4155f-20cb-4931-9dc5-34f45b9bf20b	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 18:57:08.714
8e8f7c4e-d68e-4709-961b-c9ef2132a2d9	75270371-a8c1-4056-9ec2-27d1b4849b51	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 19:02:35.78
174caa51-5b00-4c76-ad8b-aa2bb8a06f92	5f4306df-4148-4c85-b752-e2a56d7a4f15	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 19:12:46.952
da171374-4240-4c53-b157-ceaea64d2bb3	c5648f92-c9a1-48a4-8670-5756d4903676	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 19:25:55.969
b242f849-5b27-453f-929c-d37d75b94734	67f938b2-b4b8-4e13-ae10-41bee5ee2bff	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 20:27:19.494
b1180e1a-3dc1-4f03-a8bd-fb9ec94291d8	33b29a90-86af-4d79-bfbe-b11c9e447ff3	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 21:36:22.105
e1a0cc56-3fae-43e5-a719-c3405f8e3435	6e2ec856-7a42-46b5-ace2-d853e3937348	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 21:46:22.497
6c688a47-f5a2-4242-a0c7-bfe60a53d44b	916ffe65-210b-4ba6-b48b-94e0cf8533d8	2506dbe3-68a1-4570-bad5-873540371703	2026-01-14 23:40:19.069
df08d681-e8a2-403f-847c-56e8f4909231	24da84f4-b0e9-4253-9711-c2e146360354	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 02:23:04.052
800481ee-50d3-45e1-bebb-486ec42df785	57f7d7a1-66eb-4231-9d1c-4f687a8aa134	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 02:45:32.105
da663d7d-0296-4d17-adf0-b9d88f3657eb	69257d2f-05a5-4c26-8f24-4e24faf4a4f5	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 14:55:14.781
45ec1e1d-97f7-42a0-bac3-29993fe0d2d3	3c2eeb6b-5fd7-413d-a8ff-9aeddb3019f8	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 14:55:29.692
20a18da5-191c-49e1-93b3-e9d76ae9032b	7e94fa07-108a-4f60-a2b2-d3435c83338f	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 14:58:08.279
85f690b7-0d55-44f2-9eb3-032095a8ff21	4570c2e4-7fe1-43dc-9edd-bbd6c1c14c65	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 17:11:39.745
ec7b70c3-f31c-4362-bbd2-6ccd5f625b91	512ed163-2f42-44e8-b8e4-415637ed319f	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 18:55:37.677
f43f21ea-d3e8-49be-ad58-cbb11b7ce903	be05d338-6f69-4ec0-86e4-cddf174ade70	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 19:49:01.091
39a9072f-e12c-4bda-8e64-01074f034bd8	d2b15204-bc26-426e-b74b-f2690b14ac06	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 20:10:03.651
ef5e4ea3-20f8-4b81-9a4b-f204c7d87e08	f432c163-5bce-40d2-a09b-c21b2c5fc70c	2506dbe3-68a1-4570-bad5-873540371703	2026-01-15 22:33:12.102
75f86bc4-7d9e-4193-887e-6071e34c3944	0f3677e8-43e1-4cb5-b5eb-19ce36e9c7ce	2506dbe3-68a1-4570-bad5-873540371703	2026-01-16 00:39:56.152
6d6a2830-8d34-416a-aac6-767cfb7344ae	7c34534c-71ed-4b96-bedb-4cf26c1a5c00	2506dbe3-68a1-4570-bad5-873540371703	2026-01-16 01:14:57.957
f8c72a00-bcf7-48c0-b925-083ea4e962da	b4f90838-15dd-4ad1-8c68-c3a5c3a7f9cc	2506dbe3-68a1-4570-bad5-873540371703	2026-01-16 22:50:11.558
afb42709-5da2-41aa-a60f-e5b26c9a0eb6	1b9fd83b-bc79-4e1b-87c1-eb45eeb17497	2506dbe3-68a1-4570-bad5-873540371703	2026-01-18 15:30:02.353
507ecef9-dad9-4184-9e18-55315cdc1333	f2df8f5b-bc93-462c-8b9a-0ba908883cd9	2506dbe3-68a1-4570-bad5-873540371703	2026-01-21 15:38:06.95
\.


--
-- TOC entry 3346 (class 2606 OID 41129)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3321 (class 2606 OID 24653)
-- Name: calificaciones calificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calificaciones
    ADD CONSTRAINT calificaciones_pkey PRIMARY KEY (id);


--
-- TOC entry 3309 (class 2606 OID 24631)
-- Name: categoriaservicios categoriaservicios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoriaservicios
    ADD CONSTRAINT categoriaservicios_pkey PRIMARY KEY (id);


--
-- TOC entry 3342 (class 2606 OID 32784)
-- Name: interacciones interacciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interacciones
    ADD CONSTRAINT interacciones_pkey PRIMARY KEY (id);


--
-- TOC entry 3339 (class 2606 OID 24683)
-- Name: precios_premium precios_premium_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.precios_premium
    ADD CONSTRAINT precios_premium_pkey PRIMARY KEY (id);


--
-- TOC entry 3348 (class 2606 OID 57772)
-- Name: redes_sociales redes_sociales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redes_sociales
    ADD CONSTRAINT redes_sociales_pkey PRIMARY KEY (id);


--
-- TOC entry 3301 (class 2606 OID 24613)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3317 (class 2606 OID 24644)
-- Name: servicios servicios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.servicios
    ADD CONSTRAINT servicios_pkey PRIMARY KEY (id);


--
-- TOC entry 3334 (class 2606 OID 24674)
-- Name: sponsors sponsors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsors
    ADD CONSTRAINT sponsors_pkey PRIMARY KEY (id);


--
-- TOC entry 3328 (class 2606 OID 24664)
-- Name: suscripciones suscripciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suscripciones
    ADD CONSTRAINT suscripciones_pkey PRIMARY KEY (id);


--
-- TOC entry 3298 (class 2606 OID 24604)
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- TOC entry 3303 (class 2606 OID 24621)
-- Name: usuarios_roles usuarios_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT usuarios_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3322 (class 1259 OID 24698)
-- Name: calificaciones_servicioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calificaciones_servicioId_idx" ON public.calificaciones USING btree ("servicioId");


--
-- TOC entry 3323 (class 1259 OID 24700)
-- Name: calificaciones_servicioId_usuarioId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "calificaciones_servicioId_usuarioId_key" ON public.calificaciones USING btree ("servicioId", "usuarioId");


--
-- TOC entry 3324 (class 1259 OID 24699)
-- Name: calificaciones_usuarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calificaciones_usuarioId_idx" ON public.calificaciones USING btree ("usuarioId");


--
-- TOC entry 3307 (class 1259 OID 24689)
-- Name: categoriaservicios_nombre_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX categoriaservicios_nombre_key ON public.categoriaservicios USING btree (nombre);


--
-- TOC entry 3310 (class 1259 OID 24690)
-- Name: categoriaservicios_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX categoriaservicios_slug_key ON public.categoriaservicios USING btree (slug);


--
-- TOC entry 3340 (class 1259 OID 32787)
-- Name: interacciones_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "interacciones_createdAt_idx" ON public.interacciones USING btree ("createdAt");


--
-- TOC entry 3343 (class 1259 OID 32785)
-- Name: interacciones_servicioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "interacciones_servicioId_idx" ON public.interacciones USING btree ("servicioId");


--
-- TOC entry 3344 (class 1259 OID 32786)
-- Name: interacciones_tipo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interacciones_tipo_idx ON public.interacciones USING btree (tipo);


--
-- TOC entry 3335 (class 1259 OID 24708)
-- Name: precios_premium_activo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX precios_premium_activo_idx ON public.precios_premium USING btree (activo);


--
-- TOC entry 3336 (class 1259 OID 24709)
-- Name: precios_premium_duracionMeses_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "precios_premium_duracionMeses_idx" ON public.precios_premium USING btree ("duracionMeses");


--
-- TOC entry 3337 (class 1259 OID 24707)
-- Name: precios_premium_duracionMeses_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "precios_premium_duracionMeses_key" ON public.precios_premium USING btree ("duracionMeses");


--
-- TOC entry 3349 (class 1259 OID 57773)
-- Name: redes_sociales_servicioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "redes_sociales_servicioId_idx" ON public.redes_sociales USING btree ("servicioId");


--
-- TOC entry 3299 (class 1259 OID 24685)
-- Name: roles_nombre_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roles_nombre_key ON public.roles USING btree (nombre);


--
-- TOC entry 3311 (class 1259 OID 24695)
-- Name: servicios_calificacionPromedio_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "servicios_calificacionPromedio_idx" ON public.servicios USING btree ("calificacionPromedio");


--
-- TOC entry 3312 (class 1259 OID 24692)
-- Name: servicios_categoriaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "servicios_categoriaId_idx" ON public.servicios USING btree ("categoriaId");


--
-- TOC entry 3313 (class 1259 OID 24693)
-- Name: servicios_comuna_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX servicios_comuna_idx ON public.servicios USING btree (comuna);


--
-- TOC entry 3314 (class 1259 OID 24697)
-- Name: servicios_fechaFin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "servicios_fechaFin_idx" ON public.servicios USING btree ("fechaFin");


--
-- TOC entry 3315 (class 1259 OID 24696)
-- Name: servicios_nivel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX servicios_nivel_idx ON public.servicios USING btree (nivel);


--
-- TOC entry 3318 (class 1259 OID 24691)
-- Name: servicios_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX servicios_slug_key ON public.servicios USING btree (slug);


--
-- TOC entry 3319 (class 1259 OID 24694)
-- Name: servicios_usuarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "servicios_usuarioId_idx" ON public.servicios USING btree ("usuarioId");


--
-- TOC entry 3331 (class 1259 OID 24706)
-- Name: sponsors_activo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sponsors_activo_idx ON public.sponsors USING btree (activo);


--
-- TOC entry 3332 (class 1259 OID 24705)
-- Name: sponsors_nivel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sponsors_nivel_idx ON public.sponsors USING btree (nivel);


--
-- TOC entry 3325 (class 1259 OID 24703)
-- Name: suscripciones_activa_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suscripciones_activa_idx ON public.suscripciones USING btree (activa);


--
-- TOC entry 3326 (class 1259 OID 24704)
-- Name: suscripciones_estadoPago_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "suscripciones_estadoPago_idx" ON public.suscripciones USING btree ("estadoPago");


--
-- TOC entry 3329 (class 1259 OID 24702)
-- Name: suscripciones_servicioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "suscripciones_servicioId_idx" ON public.suscripciones USING btree ("servicioId");


--
-- TOC entry 3330 (class 1259 OID 24701)
-- Name: suscripciones_servicioId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "suscripciones_servicioId_key" ON public.suscripciones USING btree ("servicioId");


--
-- TOC entry 3296 (class 1259 OID 24684)
-- Name: usuarios_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX usuarios_email_key ON public.usuarios USING btree (email);


--
-- TOC entry 3304 (class 1259 OID 24687)
-- Name: usuarios_roles_roleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "usuarios_roles_roleId_idx" ON public.usuarios_roles USING btree ("roleId");


--
-- TOC entry 3305 (class 1259 OID 24686)
-- Name: usuarios_roles_usuarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "usuarios_roles_usuarioId_idx" ON public.usuarios_roles USING btree ("usuarioId");


--
-- TOC entry 3306 (class 1259 OID 24688)
-- Name: usuarios_roles_usuarioId_roleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "usuarios_roles_usuarioId_roleId_key" ON public.usuarios_roles USING btree ("usuarioId", "roleId");


--
-- TOC entry 3354 (class 2606 OID 24730)
-- Name: calificaciones calificaciones_servicioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calificaciones
    ADD CONSTRAINT "calificaciones_servicioId_fkey" FOREIGN KEY ("servicioId") REFERENCES public.servicios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3355 (class 2606 OID 24735)
-- Name: calificaciones calificaciones_usuarioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calificaciones
    ADD CONSTRAINT "calificaciones_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3357 (class 2606 OID 32788)
-- Name: interacciones interacciones_servicioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interacciones
    ADD CONSTRAINT "interacciones_servicioId_fkey" FOREIGN KEY ("servicioId") REFERENCES public.servicios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3358 (class 2606 OID 32793)
-- Name: interacciones interacciones_usuarioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interacciones
    ADD CONSTRAINT "interacciones_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3359 (class 2606 OID 57774)
-- Name: redes_sociales redes_sociales_servicioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redes_sociales
    ADD CONSTRAINT "redes_sociales_servicioId_fkey" FOREIGN KEY ("servicioId") REFERENCES public.servicios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3352 (class 2606 OID 24725)
-- Name: servicios servicios_categoriaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.servicios
    ADD CONSTRAINT "servicios_categoriaId_fkey" FOREIGN KEY ("categoriaId") REFERENCES public.categoriaservicios(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3353 (class 2606 OID 24720)
-- Name: servicios servicios_usuarioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.servicios
    ADD CONSTRAINT "servicios_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3356 (class 2606 OID 24740)
-- Name: suscripciones suscripciones_servicioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suscripciones
    ADD CONSTRAINT "suscripciones_servicioId_fkey" FOREIGN KEY ("servicioId") REFERENCES public.servicios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3350 (class 2606 OID 24715)
-- Name: usuarios_roles usuarios_roles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT "usuarios_roles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3351 (class 2606 OID 24710)
-- Name: usuarios_roles usuarios_roles_usuarioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT "usuarios_roles_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2026-01-22 02:53:47 -03

--
-- PostgreSQL database dump complete
--

\unrestrict I6oaAwYpg956hZ2G3ltMfFH33VmGsP7FlreKSRTJJbOLswrGA6zuPvIEKAtj7VR

